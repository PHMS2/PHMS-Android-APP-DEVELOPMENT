package com.example.airforcebrett.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toolbar;


public class dailyTracker extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbar;







        Button bDiet, bVitalSigns, bMedication, bNotes, bMonitoringSystem, bDataMaintenance, bLogout;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_daily_tracker);

            bDiet = (Button)findViewById(R.id.bDiet);
            bVitalSigns = (Button)findViewById(R.id.bVitalSigns);
            bMedication = (Button)findViewById(R.id.bMedication);
            bNotes = (Button)findViewById(R.id.bNotes);
            bMonitoringSystem = (Button)findViewById(R.id.bMonitoringSystem);
            bDataMaintenance = (Button)findViewById(R.id.bDataMaintenance);

            bLogout=(Button) findViewById(R.id.bLogout);
            bDiet.setOnClickListener(this);
            bVitalSigns.setOnClickListener(this);
            bMedication.setOnClickListener(this);
            bNotes.setOnClickListener(this);
            bMonitoringSystem.setOnClickListener(this);
            bDataMaintenance.setOnClickListener(this);

            bLogout.setOnClickListener(this);




        }

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.bDiet:
                    startActivity(new Intent(this, Diet.class));
                    break;
                case R.id.bVitalSigns:
                    startActivity(new Intent(this, vitalSigns.class));
                    break;
                case R.id.bMedication:
                    startActivity(new Intent(this, Medication.class));
                    break;
                case R.id.bDataMaintenance:
                    startActivity(new Intent(this, datamaint.class));
                    break;
                case R.id.bMonitoringSystem:
                    startActivity(new Intent(this, MonitoringSystem.class));
                    break;
                case R.id.bNotes:
                    startActivity(new Intent(this, Notes.class));
                    break;
                case R.id.bLogout:
                    startActivity(new Intent(this, Login.class));
                    break;

            }
        }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_daily_tracker, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        switch (item.getItemId()) {
            case R.id.action_search:
                startActivity(new Intent(this, addNote.class));//add code for search activity
                break;

        }

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
