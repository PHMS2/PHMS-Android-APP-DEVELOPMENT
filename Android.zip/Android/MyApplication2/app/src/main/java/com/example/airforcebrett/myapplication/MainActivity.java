package com.example.airforcebrett.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button bDiet, bVitalSigns, bMedication, bNotes, bMonitoringSystem, bDataMaintenance, bSearch, bLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bDiet = (Button)findViewById(R.id.bDiet);
        bVitalSigns = (Button)findViewById(R.id.bVitalSigns);
        bMedication = (Button)findViewById(R.id.bMedication);
        bNotes = (Button)findViewById(R.id.bNotes);
        bMonitoringSystem = (Button)findViewById(R.id.bMonitoringSystem);
        bDataMaintenance = (Button)findViewById(R.id.bDataMaintenance);
        bSearch = (Button)findViewById(R.id.bSearch);
        bLogout=(Button) findViewById(R.id.bLogout);
        bDiet.setOnClickListener(this);
        bVitalSigns.setOnClickListener(this);
        bMedication.setOnClickListener(this);
        bNotes.setOnClickListener(this);
        bMonitoringSystem.setOnClickListener(this);
        bDataMaintenance.setOnClickListener(this);
        bSearch.setOnClickListener(this);
        bLogout.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bDiet:
                break;
            case R.id.bVitalSigns:
                break;
            case R.id.bMedication:
                break;
            case R.id.bDataMaintenance:
                break;
            case R.id.bMonitoringSystem:
                startActivity(new Intent(this, MonitoringSystem.class));
                break;
            case R.id.bNotes:
                startActivity(new Intent(this, Notes.class));
                break;
            case R.id.bSearch:
                break;
            case R.id.bLogout:
                startActivity(new Intent(this, Login.class));
                break;

        }
    }
    }


